# OpenHilo 工作流脚本支持契约

[English](LANGUAGE.md)

OpenHilo 使用**有限的 TypeScript 语法子集作为可恢复工作流的脚本和胶水**，用于传递普通数据、选择分支、重复步骤及调用
AI、Human、Code 和子工作流。它不是完整 TS/Node 执行环境，也不承诺把任意程序变成可恢复程序。

**本文件定义支持的语法。** [兼容性文档](../../docs/compatibility.md)定义数据与恢复边界。复杂计算和环境
API 放到 Code executor 中，Code 内部不支持任意位置恢复。

执行器命名建议采用「业务动作 + 业务对象 + 执行方」：从任务承担者的角度描述工作，例如 `provide_topic_by_human`、
`draft_report_by_ai`、`save_report_by_code`。详见[命名规范](../../docs/executor-naming.md)。该规范用于提高可读性，不额外限制合法函数名。

## 1. 支持与拒绝总表

| 类别    | 支持                                                           | 不支持（编译时拒绝，动态数据见第 6 节）                                                  |
|-------|--------------------------------------------------------------|------------------------------------------------------------------------|
| 变量    | 显式初始化的 let/const、块级作用域、内层同名遮蔽                                | var、声明前访问、块外访问、const 重赋值、重复声明；工作流变量命名 undefined/NaN/Infinity           |
| 控制流   | if/else、块、计数 for、while、数组 for-of、break/continue/return，以及嵌套  | switch、do-while、for-in、for-await、try/catch/finally、throw、标签跳转、debugger |
| 更新    | 独立语句/计数 for 初始化及步进中的变量、属性、下标赋值、复合/逻辑赋值、前后置增减                 | 条件、参数、右值、回调等内部嵌入对外层工作流变量的赋值/增减；可选链赋值                                   |
| 普通表达式 | 支持数据的字面量、算术/比较/逻辑/条件运算、typeof、模板字符串、属性/下标、可选链、数组/对象展开、指定内建操作 | delete、void、instanceof、this/super/globalThis、带标签模板、类、未知全局、原型反射         |
| 解构    | 声明、已有变量重赋值、数组 for-of 声明头；静态键、重命名、默认值、嵌套、跳项、rest              | 计算键、成员写入目标、默认值中的 await、非声明 for-of 头、括号包裹赋值目标                           |
| 调用    | 已知工作流/执行器直接 await，具名相对导入，跨文件无环调用                             | 递归、动态函数/方法别名、工作流函数当作值、任意 Promise、并发、异步回调、生成器                           |
| 函数接口  | 具名必填参数，明确命名输出对象，普通返回表达式                                      | 默认/可选/rest/解构/this 参数；不透明或可选输出字段                                       |
| TS 注解 | 下表数据类型及表达式类型语法擦除                                             | 完整类型检查、用户 interface/type 别名解析、泛型工作流和高级类型运算                             |
| 环境    | 经执行器访问外部能力                                                   | 工作流直接 require/npm/文件/网络/进程/定时器；未列出的全局 API                              |

“支持”包含允许构件在允许位置的组合，以及作用域、短路、求值顺序、引用关系和恢复一致性。受支持组合的语义错误属于
bug，不通过临时追加限制规避。编译通过不是对动态数据和外部能力成功的保证。

## 2. 工作流与调用

`compileProgram` 消费封闭的虚拟 .ts 文件集合和显式导出入口，不读取源码文件系统。每个文件可有多个导出/私有 async 工作流，
`import {child as runChild} from './child'` 按导出身份解析。拒绝顶层执行步骤、缺失/私有导入、路径越界、重复名字和调用环。只支持具名导出/导入，默认导出、混合默认导入和
import attributes 均拒绝。工作流声明与执行器声明位于模块顶层，不支持嵌套工作流函数。工作流、执行器、导入别名及已注册系统能力共用调用名空间，重名/重载明确拒绝，不能悄悄选择第一个声明。

工作流输入必须具名、必填；正常结束路径必须返回具有明确自有字段的普通对象。循环保守视为可能零次执行，不能仅靠循环内 return
证明完整返回。返回值可来自变量、条件、属性、方法调用、对象展开或计算字段；只求值一次。静态可知字段错误在编译时拒绝，动态缺失/多余字段、null、数组、原始值和不可保存值在运行时拒绝。空输出也要返回符合空字段契约的对象。

```ts
let result = (await (child)(input));
result = await child(input);
({value} = await child(input));
box.result = await child(input);
rows[index] = await child(input);
return (await child(input));
```

await 只能作为声明初始化、独立语句、简单赋值右侧或返回的完整操作数；透明括号和类型包装不改变规则。不支持参数/算术/解构默认值中的嵌套
await，也不支持 `x += await child()`。业务参数数量必须匹配，不支持调用参数展开。属性接收者和下标在调用前求值一次，恢复后写回原目标。内部子工作流参数与整个返回对象保留引用关系。

AI 的 role/prompt、Human 的 prompt、Code 的 lang/script 是静态字符串或无插值模板；constraints 是静态字符串数组，AI skills
是声明元数据。动态业务内容作为后续业务参数传入。执行器必须使用无函数体的 `declare function`
；真实实现放在适配器中，带函数体的执行器声明会被拒绝。`_by_code`
仅接受一个可选具名输入对象字面量（静态标识符键），不接受 spread/计算键/方法/额外位置参数。`_by_sys`
只有宿主显式注册的方法可用；核心不内置实体、定时等业务能力。

## 3. 更新、解构与同步表达式

变量和成员更新放在独立语句或允许的循环位置。`rows[i++] = x` 不支持，可写成 `rows[i] = x; i++;`。对象、键、右值按 JS
顺序求值；逻辑赋值保持短路。`(obj.x = 2)` 可用，`(obj.x) = 2` 不支持。严格模式下给原始值写属性报错。

普通解构右值只求值一次，默认值只在对应值为 undefined 时执行，rest 是浅拷贝。解构后的持久变量仍不允许 undefined：用默认值或
null。`for (const {id, name = "anon", ...rest} of rows)` 复用同一绑定规则；只遍历数组，保留原数组和游标，push/splice
对后续遍历的影响与 JS 数组 for-of 一致。退出作用域、break/continue 和返回都应释放不可达临时根。

可选属性、下标、调用可组合，例如 `a?.b.c`、`a?.[key].items[0]?.name`、`rows?.slice?.(1).length`。短路范围、接收者和求值顺序遵循
JS；`(a?.b).c` 的括号结束链，而 TS 非空断言不会。短路产生的 undefined 只能作为中间值，保存前使用 `?? null` 等默认值。

函数表达式仅限同步立即调用（IIFE）或直接作为以下方法的同步回调：map/filter/reduce/reduceRight/find/findIndex/findLast/findLastIndex/some/every/flatMap/sort/toSorted/forEach/from/replace/replaceAll。回调内部局部变量使用原生
JS 语义，但仍受表达式准入规则限制；不能保存/返回函数、读取函数源码、使用异步/生成器回调或更新外层工作流变量绑定。修改共享普通对象仍遵循数据规则。工作流调用不能放进同步回调。

已知直接调用支持透明括号、擦除型 TS 包装和静态方法选择，例如 `(Math.max)(1,2)`、`Math["max"](1,2)`、`rows["map"](x=>x.id)`
。允许的全局操作完整列表见[内建操作](../../docs/compatibility.md#direct-intrinsics)
。未列全局、内建命名空间/方法别名、动态内建查找或修改拒绝。普通对象/数组/字符串方法由 JS 求值，但函数逸出、不可保存结果与反射仍被检查，不代表完整内建库兼容。

## 4. 类型契约与入口参数

| TS 注解                                 | ITT kind   |
|---------------------------------------|------------|
| string / 字符串字面量及同类联合                  | text       |
| number / 数字字面量及同类联合                   | number     |
| boolean / 布尔字面量及同类联合                  | boolean    |
| 普通对象、数组、Array、ReadonlyArray、元组、Record | json       |
| any、unknown、无注解、null、混合联合             | json       |
| 独立 FilePath / DirPath                 | file / dir |

括号和 readonly 包装复用映射。编译后的工作流入口参数额外保留 `shape`：字段、可选属性、数组、元组、字面量集合、联合及 Record/索引值类型。使用 `typed-text-v1` 的宿主在执行前校验该结构，也可据此生成逐字段表单。额外对象字段按结构类型规则保留，声明的索引签名仍约束对应值。any、unknown 和无注解参数仍是无结构 JSON。旧产物需重新编译才有结构信息。旧输入编码、内部调用、局部变量和输出仍使用上表粗粒度契约；这不是完整 TypeScript 类型检查。未知命名/高级/函数类型明确拒绝，嵌套和解构局部注解也检查。只允许历史
FilePath/DirPath 标记别名，不解析用户类型别名。输出要求 `Promise<{明确且必填的静态命名字段}>`，不支持可选输出、索引输出或不透明输出类型。历史
Promise<void>/无返回注解表示空输出契约，实际对象结果规则不变。

`as`、类型断言、satisfies、非空断言及同步回调的类型注解在表达式发射时擦除；不产生运行时转换或结构验证。需要额外辅助语句的类型语法不支持。工作流/执行器签名中的泛型不支持。

## 5. 数据与恢复

可保存：null、布尔、字符串、有限数值（不含
-0）、普通可修改对象和稠密数组，包括共享但无环的引用图。不可保存：undefined、NaN/Infinity/-0、空洞/额外属性数组、循环引用、函数/Promise、Date/Map/Set/RegExp/BigInt、访问器/Proxy、符号/隐藏属性、自定义/null
原型、冻结/密封/不可扩展对象及只读属性。静态可知时编译拒绝，动态值运行时拒绝，不能丢字段或转 null。

`const b = a` 共享对象，展开/rest 只浅拷贝；整个调用栈的变量、循环游标、返回对象通过 StateGraph
保存关系。恢复不重放已完成节点。AI/Human/Code 是隔离的数据边界，外部 JSON 协议不承诺跨边界对象身份。流程中的 ordinary JSON
不因长得像 FileRef 而转换；只有明确 file/dir 边界将真实 FileRef 投影成路径。

恢复不等于保存整个进程：PID/内存地址可能变，等待期间时间流逝，外部文件/服务会变。已记录值保持；后续读取获取当前外部状态。不承诺任意崩溃下外部副作用恰好一次。详见[兼容性文档](../../docs/compatibility.md)
。这套检查不是安全沙箱。

## 6. 报错和旧入口

- 不支持的静态语法/声明/调用必须在编译时拒绝；compileProgram 返回诊断且 artifacts 为空，不能跳过非法步骤或产出部分流程。
- 错误说明原因，源码错误尽可能附文件、行、列；运行时错误标识失败节点，数据错误尽可能指明字段路径。未知语法不得通过 fallback
  忽略。
- 数据相关错误在相应操作/保存边界明确中止；不假装成功、不默默修正。外部动作已发生时不能承诺回滚。
- 旧脚本式 astToITT 没有函数输出契约，return-await 和动态形状返回拒绝；推荐 compileProgram。旧一文件一同名工作流解析器不能处理多导出歧义，须改用
  compileProgram。
- 新产物依赖配套 compiler/contracts/runtime；旧无 plain-data/result 元数据产物保留历史语义，已有快照不改写。重新编译并创建新运行才获得新语义，不能混搭旧新产物期待修复引用。

## 7. 验证与问题反馈

`npm run test:semantics` 对照原生 JS、连续执行和跨进程恢复，覆盖受支持语法的组合、明确拒绝的形式和动态数据边界。
详见[测试与兼容性](../../docs/validation.md)。这些检查不代表完整 JavaScript 一致性认证。
如果受支持的写法产生不同语义，请提交最小源码、输入、Node 版本以及预期与实际结果；不要附带凭据或私密运行数据。

## AI 类型与档位标签

AI 的 declare function 支持可选 JSDoc 标签 `@ai.type` 和 `@ai.level`，不改变 role、prompt 和业务参数。未写类型走 default，未写档位走该类型的 defaultLevel；显式缺失配置报错，不自动切换。详见 [AI 路由](../../docs/ai-routing.md) 和可运行示例。
